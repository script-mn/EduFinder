"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Phone, Globe, Star, Calendar, Users, BookOpen, DollarSign, FileText, Clock } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

// Mock data for institution details
const institutionData = {
  1: {
    id: 1,
    name: "Tribhuvan University",
    type: "University",
    address: "Kirtipur, Kathmandu, Nepal",
    phone: "+977-1-4330433",
    email: "info@tu.edu.np",
    website: "www.tu.edu.np",
    rating: 4.5,
    established: 1959,
    students: 25000,
    faculty: 1200,
    image: "/placeholder.svg?height=400&width=800",
    description:
      "Tribhuvan University is the oldest and largest university in Nepal. It was established in 1959 and offers a wide range of undergraduate and graduate programs across various disciplines.",
    programs: [
      {
        name: "BSc.CSIT",
        duration: "4 years",
        fee: "NPR 80,000",
        seats: 120,
        entrance: "TU Entrance Exam",
        description: "Bachelor of Science in Computer Science and Information Technology",
      },
      {
        name: "BBA",
        duration: "4 years",
        fee: "NPR 60,000",
        seats: 200,
        entrance: "TU Entrance Exam",
        description: "Bachelor of Business Administration",
      },
      {
        name: "Engineering",
        duration: "4 years",
        fee: "NPR 150,000",
        seats: 300,
        entrance: "IOE Entrance Exam",
        description: "Various engineering disciplines available",
      },
    ],
    facilities: [
      "Central Library with 500,000+ books",
      "Computer Labs with latest equipment",
      "Sports Complex",
      "Hostels for students",
      "Medical Center",
      "Cafeteria and Food Courts",
    ],
    admissionProcess: [
      "Fill out the online application form",
      "Submit required documents",
      "Appear for entrance examination",
      "Merit list publication",
      "Document verification",
      "Fee payment and enrollment",
    ],
    entrancePrep: {
      examName: "TU Entrance Exam",
      subjects: ["English", "Mathematics", "Science", "General Knowledge"],
      duration: "2 hours",
      totalMarks: 100,
      preparationTips: [
        "Focus on basic concepts in Mathematics and Science",
        "Practice previous year question papers",
        "Improve English vocabulary and grammar",
        "Stay updated with current affairs",
      ],
    },
  },
}

export default function InstitutionPage() {
  const params = useParams()
  const id = params.id as string
  const institution = institutionData[1] // Using mock data
  const [activeTab, setActiveTab] = useState("overview")

  if (!institution) {
    return <div>Institution not found</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/search" className="text-blue-600 hover:text-blue-800">
            ← Back to Search Results
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <img
                src={institution.image || "/placeholder.svg"}
                alt={institution.name}
                className="w-full h-64 object-cover rounded-lg mb-6"
              />

              <div className="flex justify-between items-start mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{institution.name}</h1>
                  <div className="flex items-center text-gray-600 mb-2">
                    <MapPin className="h-5 w-5 mr-2" />
                    {institution.address}
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-400 mr-1" />
                      <span className="font-medium">{institution.rating}</span>
                    </div>
                    <Badge variant="secondary">{institution.type}</Badge>
                  </div>
                </div>
              </div>

              <p className="text-gray-700 mb-6">{institution.description}</p>
            </div>

            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-3 text-gray-400" />
                    <div>
                      <p className="font-medium">Established</p>
                      <p className="text-gray-600">{institution.established}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-3 text-gray-400" />
                    <div>
                      <p className="font-medium">Students</p>
                      <p className="text-gray-600">{institution.students.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-3 text-gray-400" />
                    <div>
                      <p className="font-medium">Faculty</p>
                      <p className="text-gray-600">{institution.faculty}</p>
                    </div>
                  </div>
                  <div className="pt-4 space-y-2">
                    <Button className="w-full">
                      <Phone className="h-4 w-4 mr-2" />
                      Contact Institution
                    </Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Globe className="h-4 w-4 mr-2" />
                      Visit Website
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Information */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="programs">Programs</TabsTrigger>
            <TabsTrigger value="admission">Admission</TabsTrigger>
            <TabsTrigger value="facilities">Facilities</TabsTrigger>
            <TabsTrigger value="entrance">Entrance Prep</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>About the Institution</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">{institution.description}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-medium">Type:</span>
                      <span>{institution.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Established:</span>
                      <span>{institution.established}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Total Students:</span>
                      <span>{institution.students.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Faculty Members:</span>
                      <span>{institution.faculty}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 mr-3 text-gray-400" />
                    <span>{institution.address}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 mr-3 text-gray-400" />
                    <span>{institution.phone}</span>
                  </div>
                  <div className="flex items-center">
                    <Globe className="h-5 w-5 mr-3 text-gray-400" />
                    <span>{institution.website}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="programs" className="mt-6">
            <div className="grid gap-6">
              {institution.programs.map((program, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{program.name}</CardTitle>
                        <CardDescription>{program.description}</CardDescription>
                      </div>
                      <Badge variant="outline">{program.duration}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-4 gap-4">
                      <div className="flex items-center">
                        <DollarSign className="h-5 w-5 mr-2 text-gray-400" />
                        <div>
                          <p className="font-medium">Annual Fee</p>
                          <p className="text-gray-600">{program.fee}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Users className="h-5 w-5 mr-2 text-gray-400" />
                        <div>
                          <p className="font-medium">Available Seats</p>
                          <p className="text-gray-600">{program.seats}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-gray-400" />
                        <div>
                          <p className="font-medium">Entrance Exam</p>
                          <p className="text-gray-600">{program.entrance}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 mr-2 text-gray-400" />
                        <div>
                          <p className="font-medium">Duration</p>
                          <p className="text-gray-600">{program.duration}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="admission" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Admission Process</CardTitle>
                <CardDescription>Follow these steps to apply for admission</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {institution.admissionProcess.map((step, index) => (
                    <div key={index} className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium mr-4">
                        {index + 1}
                      </div>
                      <p className="text-gray-700">{step}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="facilities" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Campus Facilities</CardTitle>
                <CardDescription>Available facilities and amenities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {institution.facilities.map((facility, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      <span>{facility}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="entrance" className="mt-6">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Entrance Examination Details</CardTitle>
                  <CardDescription>Information about {institution.entrancePrep.examName}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-2">Exam Structure</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Duration:</span>
                          <span>{institution.entrancePrep.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Marks:</span>
                          <span>{institution.entrancePrep.totalMarks}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Subjects</h4>
                      <div className="flex flex-wrap gap-2">
                        {institution.entrancePrep.subjects.map((subject, index) => (
                          <Badge key={index} variant="outline">
                            {subject}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Preparation Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {institution.entrancePrep.preparationTips.map((tip, index) => (
                      <div key={index} className="flex items-start">
                        <div className="w-2 h-2 bg-green-600 rounded-full mr-3 mt-2"></div>
                        <span>{tip}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
