"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MapPin, Phone, Star, Filter, Map } from "lucide-react"
import Link from "next/link"

// Mock data for institutions
const mockInstitutions = [
  {
    id: 1,
    name: "Tribhuvan University",
    type: "University",
    address: "Kirtipur, Kathmandu",
    distance: "2.5 km",
    rating: 4.5,
    phone: "+977-1-4330433",
    website: "www.tu.edu.np",
    programs: ["BSc.CSIT", "BBA", "Engineering", "Medicine"],
    fees: "NPR 50,000 - 200,000",
    image: "/placeholder.svg?height=200&width=300",
    established: 1959,
    students: 25000,
  },
  {
    id: 2,
    name: "Kathmandu University",
    type: "University",
    address: "Dhulikhel, Kavre",
    distance: "15.2 km",
    rating: 4.7,
    phone: "+977-11-661399",
    website: "www.ku.edu.np",
    programs: ["Engineering", "Medicine", "Management", "Arts"],
    fees: "NPR 100,000 - 500,000",
    image: "/placeholder.svg?height=200&width=300",
    established: 1991,
    students: 15000,
  },
  {
    id: 3,
    name: "St. Xavier's College",
    type: "College",
    address: "Maitighar, Kathmandu",
    distance: "3.8 km",
    rating: 4.6,
    phone: "+977-1-4221065",
    website: "www.sxc.edu.np",
    programs: ["BBA", "BBS", "Plus Two Science", "Plus Two Management"],
    fees: "NPR 30,000 - 80,000",
    image: "/placeholder.svg?height=200&width=300",
    established: 1988,
    students: 3000,
  },
  {
    id: 4,
    name: "Budhanilkantha School",
    type: "School",
    address: "Budhanilkantha, Kathmandu",
    distance: "8.1 km",
    rating: 4.3,
    phone: "+977-1-4371952",
    website: "www.bnks.edu.np",
    programs: ["SEE", "Plus Two Science", "Plus Two Management"],
    fees: "NPR 15,000 - 40,000",
    image: "/placeholder.svg?height=200&width=300",
    established: 1972,
    students: 2500,
  },
]

function SearchContent() {
  const searchParams = useSearchParams()
  const [institutions, setInstitutions] = useState(mockInstitutions)
  const [filteredInstitutions, setFilteredInstitutions] = useState(mockInstitutions)
  const [filters, setFilters] = useState({
    type: "all",
    program: "all",
    feeRange: "all",
    rating: "all",
  })
  const [searchQuery, setSearchQuery] = useState("")
  const [showMap, setShowMap] = useState(false)

  const location = searchParams.get("location") || ""

  useEffect(() => {
    // Apply filters
    let filtered = institutions

    if (filters.type !== "all") {
      filtered = filtered.filter((inst) => inst.type.toLowerCase() === filters.type)
    }

    if (filters.program !== "all") {
      filtered = filtered.filter((inst) =>
        inst.programs.some((program) => program.toLowerCase().includes(filters.program.toLowerCase())),
      )
    }

    if (filters.rating !== "all") {
      const minRating = Number.parseFloat(filters.rating)
      filtered = filtered.filter((inst) => inst.rating >= minRating)
    }

    if (searchQuery) {
      filtered = filtered.filter(
        (inst) =>
          inst.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          inst.programs.some((program) => program.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    }

    setFilteredInstitutions(filtered)
  }, [filters, searchQuery, institutions])

  const institutionTypes = ["all", "university", "college", "school"]
  const programs = ["all", "bsc.csit", "bba", "engineering", "medicine", "plus two science"]
  const ratings = ["all", "4.0", "4.5"]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-blue-600">
              EduFinder
            </Link>
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search institutions or programs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64"
              />
              <Button variant={showMap ? "default" : "outline"} onClick={() => setShowMap(!showMap)}>
                <Map className="h-4 w-4 mr-2" />
                {showMap ? "Hide Map" : "Show Map"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Info */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Educational Institutions near "{location}"</h1>
          <p className="text-gray-600">Found {filteredInstitutions.length} institutions matching your criteria</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Institution Type */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Institution Type</label>
                  <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {institutionTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type === "all" ? "All Types" : type.charAt(0).toUpperCase() + type.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Programs */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Programs</label>
                  <Select value={filters.program} onValueChange={(value) => setFilters({ ...filters, program: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {programs.map((program) => (
                        <SelectItem key={program} value={program}>
                          {program === "all" ? "All Programs" : program.toUpperCase()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Rating */}
                <div>
                  <label className="text-sm font-medium mb-2 block">Minimum Rating</label>
                  <Select value={filters.rating} onValueChange={(value) => setFilters({ ...filters, rating: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ratings.map((rating) => (
                        <SelectItem key={rating} value={rating}>
                          {rating === "all" ? "Any Rating" : `${rating}+ Stars`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            {showMap && (
              <Card className="mb-6">
                <CardContent className="p-4">
                  <div className="h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Map integration would be implemented here</p>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-6">
              {filteredInstitutions.map((institution) => (
                <Card key={institution.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-4 gap-6">
                      <div className="md:col-span-1">
                        <img
                          src={institution.image || "/placeholder.svg"}
                          alt={institution.name}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      </div>
                      <div className="md:col-span-3">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="text-xl font-bold text-gray-900 mb-1">{institution.name}</h3>
                            <div className="flex items-center text-gray-600 mb-2">
                              <MapPin className="h-4 w-4 mr-1" />
                              {institution.address} • {institution.distance}
                            </div>
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span className="font-medium">{institution.rating}</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                          <Badge variant="secondary">{institution.type}</Badge>
                          <span>Est. {institution.established}</span>
                          <span>{institution.students.toLocaleString()} students</span>
                        </div>

                        <div className="mb-3">
                          <p className="text-sm text-gray-600 mb-2">Programs offered:</p>
                          <div className="flex flex-wrap gap-2">
                            {institution.programs.map((program, index) => (
                              <Badge key={index} variant="outline">
                                {program}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-600">
                            <p className="font-medium">Fee Range: {institution.fees}</p>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Phone className="h-4 w-4 mr-1" />
                              Contact
                            </Button>
                            <Link href={`/institution/${institution.id}`}>
                              <Button size="sm">View Details</Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SearchContent />
    </Suspense>
  )
}
