"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Search, GraduationCap, BookOpen, Users, Award } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const [location, setLocation] = useState("")
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [isDetecting, setIsDetecting] = useState(false)
  const router = useRouter()

  const detectLocation = () => {
    setIsDetecting(true)
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
          setLocation(`${position.coords.latitude}, ${position.coords.longitude}`)
          setIsDetecting(false)
        },
        (error) => {
          console.error("Error detecting location:", error)
          setIsDetecting(false)
        },
      )
    }
  }

  const handleSearch = () => {
    if (location.trim()) {
      router.push(`/search?location=${encodeURIComponent(location)}`)
    }
  }

  const features = [
    {
      icon: <MapPin className="h-8 w-8 text-blue-600" />,
      title: "Location-Based Search",
      description: "Find institutions near you with automatic location detection",
    },
    {
      icon: <GraduationCap className="h-8 w-8 text-green-600" />,
      title: "Comprehensive Profiles",
      description: "Detailed information about courses, fees, and admission processes",
    },
    {
      icon: <BookOpen className="h-8 w-8 text-purple-600" />,
      title: "Course Guidance",
      description: "Understand different programs and find the right fit for you",
    },
    {
      icon: <Award className="h-8 w-8 text-orange-600" />,
      title: "Entrance Preparation",
      description: "Get guidance on entrance exams and preparation materials",
    },
  ]

  const popularPrograms = [
    { name: "BSc.CSIT", category: "Technology", institutions: 45 },
    { name: "BBA", category: "Business", institutions: 67 },
    { name: "MBBS", category: "Medical", institutions: 23 },
    { name: "Engineering", category: "Technology", institutions: 89 },
    { name: "Plus Two Science", category: "Higher Secondary", institutions: 156 },
    { name: "BCA", category: "Technology", institutions: 78 },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">EduFinder</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <Link href="/about" className="text-gray-600 hover:text-gray-900">
                About
              </Link>
              <Link href="/guide" className="text-gray-600 hover:text-gray-900">
                Education Guide
              </Link>
              <Link href="/contact" className="text-gray-600 hover:text-gray-900">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Find Your Perfect
            <span className="text-blue-600"> Educational Institution</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Discover schools, colleges, and universities near you. Get complete guidance on courses, fees, admission
            processes, and entrance preparations - all in one place.
          </p>

          {/* Search Section */}
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Enter your location or city"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="text-lg"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={detectLocation}
                    variant="outline"
                    disabled={isDetecting}
                    className="whitespace-nowrap bg-transparent"
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    {isDetecting ? "Detecting..." : "Use My Location"}
                  </Button>
                  <Button onClick={handleSearch} size="lg">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Why Choose EduFinder?</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h4 className="text-xl font-semibold mb-2">{feature.title}</h4>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Popular Programs */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Popular Programs</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularPrograms.map((program, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-xl font-semibold">{program.name}</h4>
                  <Badge variant="secondary">{program.category}</Badge>
                </div>
                <p className="text-gray-600 flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  {program.institutions} institutions available
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold mb-4">New to Higher Education?</h3>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Don't worry! Our comprehensive guide will help you understand different programs, admission processes, and
            career paths.
          </p>
          <Link href="/guide">
            <Button size="lg" variant="secondary">
              <BookOpen className="h-5 w-5 mr-2" />
              Read Our Education Guide
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <GraduationCap className="h-6 w-6" />
                <span className="text-xl font-bold">EduFinder</span>
              </div>
              <p className="text-gray-400">Your trusted companion for finding the perfect educational institution.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/search" className="hover:text-white">
                    Search Institutions
                  </Link>
                </li>
                <li>
                  <Link href="/guide" className="hover:text-white">
                    Education Guide
                  </Link>
                </li>
                <li>
                  <Link href="/programs" className="hover:text-white">
                    Programs
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help" className="hover:text-white">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-white">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 EduFinder. All rights reserved to Mukesh Neupane.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
