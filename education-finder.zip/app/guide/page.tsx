import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Users, Award, Clock, DollarSign } from "lucide-react"
import Link from "next/link"

export default function GuidePage() {
  const educationLevels = [
    {
      title: "School Education (Class 1-10)",
      description: "Foundation education covering basic subjects",
      duration: "10 years",
      ageRange: "5-15 years",
      subjects: ["Mathematics", "Science", "English", "Social Studies", "Nepali"],
      outcome: "SEE (Secondary Education Examination) Certificate",
    },
    {
      title: "Higher Secondary (+2)",
      description: "Specialized education in chosen stream",
      duration: "2 years",
      ageRange: "16-17 years",
      subjects: ["Science", "Management", "Humanities", "Education", "Law"],
      outcome: "+2 Certificate for university admission",
    },
    {
      title: "Bachelor's Degree",
      description: "Undergraduate programs in various disciplines",
      duration: "3-4 years",
      ageRange: "18-22 years",
      subjects: ["Engineering", "Medicine", "Business", "Arts", "Science"],
      outcome: "Bachelor's degree for career or further studies",
    },
    {
      title: "Master's Degree",
      description: "Advanced studies and specialization",
      duration: "2 years",
      ageRange: "22+ years",
      subjects: ["Specialized fields", "Research", "Professional programs"],
      outcome: "Master's degree for advanced careers",
    },
  ]

  const popularPrograms = [
    {
      name: "BSc.CSIT",
      fullName: "Bachelor of Science in Computer Science and Information Technology",
      duration: "4 years",
      career: "Software Developer, IT Consultant, System Analyst",
      averageFee: "NPR 80,000/year",
      difficulty: "Medium",
    },
    {
      name: "BBA",
      fullName: "Bachelor of Business Administration",
      duration: "4 years",
      career: "Business Manager, Marketing Executive, Entrepreneur",
      averageFee: "NPR 60,000/year",
      difficulty: "Easy",
    },
    {
      name: "MBBS",
      fullName: "Bachelor of Medicine and Bachelor of Surgery",
      duration: "5.5 years",
      career: "Doctor, Medical Officer, Specialist",
      averageFee: "NPR 500,000/year",
      difficulty: "Very Hard",
    },
    {
      name: "Engineering",
      fullName: "Bachelor of Engineering (Various Fields)",
      duration: "4 years",
      career: "Engineer, Project Manager, Technical Consultant",
      averageFee: "NPR 150,000/year",
      difficulty: "Hard",
    },
  ]

  const admissionSteps = [
    {
      step: 1,
      title: "Choose Your Stream",
      description: "Decide between Science, Management, Humanities based on your interests and career goals",
    },
    {
      step: 2,
      title: "Research Institutions",
      description: "Look for colleges and universities that offer your desired program",
    },
    {
      step: 3,
      title: "Check Eligibility",
      description: "Ensure you meet the minimum requirements for your chosen program",
    },
    {
      step: 4,
      title: "Prepare for Entrance",
      description: "Study for entrance exams if required for your program",
    },
    {
      step: 5,
      title: "Apply",
      description: "Fill out application forms and submit required documents",
    },
    {
      step: 6,
      title: "Appear for Exam",
      description: "Take entrance examinations on scheduled dates",
    },
    {
      step: 7,
      title: "Merit List",
      description: "Wait for results and check if you're selected",
    },
    {
      step: 8,
      title: "Enrollment",
      description: "Complete document verification and pay fees to secure admission",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-blue-600">
              EduFinder
            </Link>
            <nav className="flex space-x-6">
              <Link href="/search" className="text-gray-600 hover:text-gray-900">
                Search
              </Link>
              <Link href="/contact" className="text-gray-600 hover:text-gray-900">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-4">Complete Education Guide</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Everything you need to know about the education system, programs, and admission processes in Nepal
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Education Levels */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Understanding Education Levels</h2>
          <div className="grid gap-6">
            {educationLevels.map((level, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{level.title}</CardTitle>
                      <CardDescription>{level.description}</CardDescription>
                    </div>
                    <Badge variant="outline">{level.duration}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-gray-400" />
                      <div>
                        <p className="font-medium">Age Range</p>
                        <p className="text-gray-600">{level.ageRange}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <BookOpen className="h-5 w-5 mr-2 text-gray-400" />
                      <div>
                        <p className="font-medium">Main Subjects</p>
                        <p className="text-gray-600">{level.subjects.join(", ")}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Award className="h-5 w-5 mr-2 text-gray-400" />
                      <div>
                        <p className="font-medium">Outcome</p>
                        <p className="text-gray-600">{level.outcome}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Popular Programs */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Popular Programs Explained</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {popularPrograms.map((program, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex justify-between items-start">
                    <div>
                      <span className="text-xl">{program.name}</span>
                      <p className="text-sm text-gray-600 font-normal mt-1">{program.fullName}</p>
                    </div>
                    <Badge
                      variant={
                        program.difficulty === "Easy"
                          ? "default"
                          : program.difficulty === "Medium"
                            ? "secondary"
                            : program.difficulty === "Hard"
                              ? "destructive"
                              : "outline"
                      }
                    >
                      {program.difficulty}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-gray-400" />
                    <span className="text-sm">Duration: {program.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-2 text-gray-400" />
                    <span className="text-sm">Average Fee: {program.averageFee}</span>
                  </div>
                  <div className="flex items-start">
                    <Users className="h-4 w-4 mr-2 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Career Opportunities:</p>
                      <p className="text-sm text-gray-600">{program.career}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Admission Process */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Step-by-Step Admission Process</h2>
          <Card>
            <CardContent className="p-6">
              <div className="space-y-6">
                {admissionSteps.map((item, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium mr-4">
                      {item.step}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* FAQ Section */}
        <section>
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Frequently Asked Questions</h2>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>What is the difference between college and university?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Universities are larger institutions that offer undergraduate, graduate, and doctoral programs across
                  multiple disciplines. Colleges are typically smaller and may focus on specific areas or offer only
                  undergraduate programs. In Nepal, both can provide quality education, but universities usually have
                  more research opportunities and diverse programs.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How do I choose the right program for me?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Consider your interests, career goals, academic strengths, and job market demand. Research different
                  programs, talk to professionals in fields you're interested in, and consider factors like program
                  duration, fees, and admission requirements. Don't hesitate to seek guidance from career counselors or
                  educational consultants.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>What are entrance examinations and how should I prepare?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Entrance examinations are competitive tests used by institutions to select students for admission.
                  They typically test your knowledge in relevant subjects and general aptitude. Prepare by studying the
                  syllabus, practicing previous years' questions, taking mock tests, and focusing on time management.
                  Many coaching centers and online resources are available to help.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>What documents do I need for admission?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Common documents include: academic transcripts and certificates, citizenship certificate,
                  passport-size photographs, entrance exam results (if applicable), migration certificate (for
                  transfers), and character certificate. Some programs may require additional documents like
                  recommendation letters or statement of purpose. Always check specific requirements with your chosen
                  institution.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2024 EduFinder. All rights reserved to Mukesh Neupane.</p>
        </div>
      </footer>
    </div>
  )
}
