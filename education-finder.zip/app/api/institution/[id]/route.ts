import { type NextRequest, NextResponse } from "next/server"

// Mock detailed institution data
const institutionDetails = {
  1: {
    id: 1,
    name: "Tribhuvan University",
    type: "University",
    address: "Kirtipur, Kathmandu, Nepal",
    coordinates: { lat: 27.6767, lng: 85.2865 },
    phone: "+977-1-4330433",
    email: "info@tu.edu.np",
    website: "www.tu.edu.np",
    rating: 4.5,
    established: 1959,
    students: 25000,
    faculty: 1200,
    description: "Tribhuvan University is the oldest and largest university in Nepal...",
    programs: [
      {
        id: 1,
        name: "BSc.CSIT",
        fullName: "Bachelor of Science in Computer Science and Information Technology",
        duration: "4 years",
        fee: 80000,
        seats: 120,
        entrance: "TU Entrance Exam",
        description: "Comprehensive program covering computer science fundamentals...",
      },
      // Add more programs...
    ],
    facilities: [
      "Central Library with 500,000+ books",
      "Computer Labs with latest equipment",
      "Sports Complex",
      "Hostels for students",
    ],
    admissionProcess: [
      "Fill out the online application form",
      "Submit required documents",
      "Appear for entrance examination",
    ],
  },
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)
  const institution = institutionDetails[id as keyof typeof institutionDetails]

  if (!institution) {
    return NextResponse.json({ error: "Institution not found" }, { status: 404 })
  }

  return NextResponse.json(institution)
}
