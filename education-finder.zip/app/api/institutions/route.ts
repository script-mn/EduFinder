import { type NextRequest, NextResponse } from "next/server"

// Mock database - In a real application, this would be replaced with actual database queries
const institutions = [
  {
    id: 1,
    name: "Tribhuvan University",
    type: "University",
    address: "Kirtipur, Kathmandu",
    coordinates: { lat: 27.6767, lng: 85.2865 },
    phone: "+977-1-4330433",
    website: "www.tu.edu.np",
    rating: 4.5,
    programs: ["BSc.CSIT", "BBA", "Engineering", "Medicine"],
    fees: { min: 50000, max: 200000 },
    established: 1959,
    students: 25000,
  },
  {
    id: 2,
    name: "Kathmandu University",
    type: "University",
    address: "Dhulikhel, Kavre",
    coordinates: { lat: 27.62, lng: 85.54 },
    phone: "+977-11-661399",
    website: "www.ku.edu.np",
    rating: 4.7,
    programs: ["Engineering", "Medicine", "Management", "Arts"],
    fees: { min: 100000, max: 500000 },
    established: 1991,
    students: 15000,
  },
  // Add more institutions...
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const location = searchParams.get("location")
  const type = searchParams.get("type")
  const program = searchParams.get("program")
  const rating = searchParams.get("rating")

  let filteredInstitutions = institutions

  // Filter by type
  if (type && type !== "all") {
    filteredInstitutions = filteredInstitutions.filter((inst) => inst.type.toLowerCase() === type.toLowerCase())
  }

  // Filter by program
  if (program && program !== "all") {
    filteredInstitutions = filteredInstitutions.filter((inst) =>
      inst.programs.some((p) => p.toLowerCase().includes(program.toLowerCase())),
    )
  }

  // Filter by rating
  if (rating && rating !== "all") {
    const minRating = Number.parseFloat(rating)
    filteredInstitutions = filteredInstitutions.filter((inst) => inst.rating >= minRating)
  }

  // In a real application, you would calculate distances based on location
  // For now, we'll just add mock distances
  const institutionsWithDistance = filteredInstitutions.map((inst) => ({
    ...inst,
    distance: `${(Math.random() * 20 + 1).toFixed(1)} km`,
  }))

  return NextResponse.json({
    institutions: institutionsWithDistance,
    total: institutionsWithDistance.length,
  })
}
